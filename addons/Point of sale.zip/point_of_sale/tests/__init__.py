# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_point_of_sale_flow
from . import test_frontend
from . import test_point_of_sale_ui
from . import test_anglo_saxon
from . import test_point_of_sale
